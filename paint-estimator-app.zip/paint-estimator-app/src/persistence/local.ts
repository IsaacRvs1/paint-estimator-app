import { AppState } from '@state/store';

const STORAGE_KEY = 'paint-estimator-state-v1';

/**
 * Save the current application state to localStorage. When called in a browser
 * context, this will persist data across page reloads. A try/catch guards
 * against quota errors and unavailable storage (e.g. in private mode).
 */
export function saveState(state: AppState): void {
  try {
    const serialised = JSON.stringify(state);
    window.localStorage.setItem(STORAGE_KEY, serialised);
  } catch (err) {
    console.warn('Unable to save state', err);
  }
}

/**
 * Load application state from localStorage. Returns undefined if nothing is
 * saved. The caller should merge the returned state with defaults and seeds.
 */
export function loadState(): Partial<AppState> | undefined {
  try {
    const serialised = window.localStorage.getItem(STORAGE_KEY);
    if (!serialised) return undefined;
    return JSON.parse(serialised) as Partial<AppState>;
  } catch (err) {
    console.warn('Unable to load state', err);
    return undefined;
  }
}

/**
 * Export the current state to a JSON string. Useful for backups or moving
 * data between devices. Does not persist to localStorage.
 */
export function exportJSON(state: AppState): string {
  return JSON.stringify(state, null, 2);
}

/**
 * Import state from a JSON string. Returns the parsed state or undefined
 * if the input is invalid. This function performs minimal validation.
 */
export function importJSON(json: string): Partial<AppState> | undefined {
  try {
    const obj = JSON.parse(json);
    if (typeof obj === 'object' && obj) {
      return obj as Partial<AppState>;
    }
  } catch (err) {
    console.warn('Invalid JSON', err);
  }
  return undefined;
}