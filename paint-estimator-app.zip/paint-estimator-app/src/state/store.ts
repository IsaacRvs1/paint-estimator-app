import { RATE_PROFILES, PRODUCTS, REPAIR_PRESETS } from '@seeds';
import { RateProfile, Product, RepairPreset } from '@seeds';
import type { Project, Room } from '@domain/calcul';

/**
 * Simple store implementation. This is not a full Redux clone but offers
 * enough structure to manage application state in a predictable manner. It
 * stores lists of projects, rate profiles, products and repairs. Widgets
 * interact with this store through actions which trigger state updates.
 */
export interface AppState {
  projects: Project[];
  rooms: Room[];
  rateProfiles: RateProfile[];
  products: Product[];
  repairPresets: RepairPreset[];
}

// Initialize the state with seeds for rates, products and repairs. Projects and
// rooms are initially empty. The seeds can later be overwritten through
// actions in the UI.
const initialState: AppState = {
  projects: [],
  rooms: [],
  rateProfiles: [...RATE_PROFILES],
  products: [...PRODUCTS],
  repairPresets: [...REPAIR_PRESETS],
};

// Internal state and subscribers list. Subscribers are invoked whenever the
// state updates.
let state: AppState = { ...initialState };
const subscribers: Array<() => void> = [];

/**
 * Subscribe to state changes. Returns an unsubscribe function.
 */
export function subscribe(listener: () => void): () => void {
  subscribers.push(listener);
  return () => {
    const index = subscribers.indexOf(listener);
    if (index >= 0) subscribers.splice(index, 1);
  };
}

/**
 * Dispatch an action that modifies the store. The reducer pattern is used
 * here for clarity but simplified. A real implementation could use a library
 * such as Redux or Zustand.
 */
export type Action =
  | { type: 'ADD_PROJECT'; project: Project }
  | { type: 'UPDATE_PROJECT'; index: number; project: Project }
  | { type: 'ADD_ROOM'; room: Room }
  | { type: 'UPDATE_ROOM'; id: string; room: Partial<Room> }
  | { type: 'RESET' };

export function dispatch(action: Action): void {
  switch (action.type) {
    case 'ADD_PROJECT':
      state = { ...state, projects: [...state.projects, action.project] };
      break;
    case 'UPDATE_PROJECT':
      state = {
        ...state,
        projects: state.projects.map((p, i) =>
          i === action.index ? { ...action.project } : p,
        ),
      };
      break;
    case 'ADD_ROOM':
      state = { ...state, rooms: [...state.rooms, action.room] };
      break;
    case 'UPDATE_ROOM':
      state = {
        ...state,
        rooms: state.rooms.map((r) =>
          r.id === action.id ? { ...r, ...action.room } : r,
        ),
      };
      break;
    case 'RESET':
      state = { ...initialState };
      break;
  }
  subscribers.forEach((fn) => fn());
}

/**
 * Selector to retrieve the current state. Consumers should treat the state as
 * immutable and avoid mutating nested objects directly. Instead, use
 * dispatch() with appropriate actions.
 */
export function getState(): AppState {
  return state;
}