/**
 * Domain calculation functions for the painting estimator. All functions in
 * this module are pure and deterministic. They operate on plain data
 * structures without any side effects. Vitest tests cover rounding rules
 * and core mathematical logic.
 */

export interface ClientInfo {
  nom: string;
  tel: string;
  email: string;
  adresse: string;
}

export interface Project {
  client: ClientInfo;
  dossierTitre: string;
  tauxHoraire: number; // $/h
  margePercent: number; // %
  taxesOn: boolean;
  fraisDeplacement: number; // $ flat fee
  perteMateriauxPercent: number; // % extra material due to waste
  depotPercent: number;
  rabaisPercent: number;
  contingencePercent: number;
}

export interface RoomOptions {
  peindreMurs: boolean;
  plafond: boolean;
  boiseries: boolean;
  portes: boolean;
  gardeRobe: boolean;
}

export interface RoomComplexities {
  plafondCathedrale: boolean;
  cageEscalier: boolean;
}

export interface RoomRatios {
  meubles: boolean;
  accesDifficile: boolean;
}

export interface Room {
  id: string;
  nom: string;
  L: number; // length in feet
  W: number; // width in feet
  H: number; // height in feet
  nbPortes: number;
  nbFenetres: number;
  linPlinthes: number; // linear feet of baseboards
  linContoursPortes: number; // linear feet of door trim
  linContoursFenetres: number; // linear feet of window trim
  options: RoomOptions;
  complexites: RoomComplexities;
  ratios: RoomRatios;
  nombreCouchesMurs: number;
  nombreCouchesPlafond: number;
  nombreCouchesBoiseries: number;
  nombreCouchesPortes: number;
}

/**
 * Compute wall surface area in square feet for a rectangular room. The
 * calculation subtracts standard areas for doors (21 sq ft) and windows (15 sq
 * ft) by default. If the caller wishes to ignore these subtractions (e.g. to
 * paint door/window trim rather than cutting around them), they can set the
 * doorSurface or windowSurface to zero.
 */
export function computeWallArea(
  L: number,
  W: number,
  H: number,
  nbPortes: number,
  nbFenetres: number,
  doorSurface = 21,
  windowSurface = 15,
): number {
  const perimeter = 2 * (L + W);
  const grossArea = perimeter * H;
  const subtract = nbPortes * doorSurface + nbFenetres * windowSurface;
  return Math.max(grossArea - subtract, 0);
}

/**
 * Compute ceiling surface area as length × width. Units are square feet.
 */
export function computeCeilingArea(L: number, W: number): number {
  return L * W;
}

/**
 * Compute the linear surface area for baseboards, door trim and window trim.
 */
export function computeLinearFeet(value: number): number {
  return value;
}

/**
 * Round hours up to the nearest quarter hour (0.25 h).
 */
export function roundHours(hours: number): number {
  return Math.ceil(hours * 4) / 4;
}

/**
 * Round monetary amounts to the nearest cent (0.01$).
 */
export function roundCurrency(amount: number): number {
  return Math.round(amount * 100) / 100;
}

/**
 * Ceil gallons to the next whole number; return both charged gallons and the
 * surplus fraction for information purposes.
 */
export function ceilGallons(gallons: number): { gallonsFactures: number; surplus: number } {
  const factures = Math.ceil(gallons);
  return { gallonsFactures: factures, surplus: factures - gallons };
}

/**
 * Compute the number of gallons required for a surface area given the
 * coverage (sqft per gallon) and number of coats. The result includes the
 * loss factor (perte%) provided by the project profile. Gallons are not
 * rounded here; rounding should occur downstream.
 */
export function computeGallons(
  surfaceSqFt: number,
  coats: number,
  coverage: number,
  pertePercent: number,
): number {
  const base = (surfaceSqFt * coats) / coverage;
  return base * (1 + pertePercent / 100);
}

/**
 * Compute the labor hours for painting a surface. The quantity should be
 * expressed in the same units as the rate (e.g. square feet or linear feet or
 * units). Multiplicative factors for preparation level, complexities and
 * site ratios should already be combined into the rate or quantity before
 * calling this function.
 */
export function computeLaborHours(
  quantity: number,
  rate: number,
  coats: number,
): number {
  if (rate <= 0) return 0;
  const hours = (quantity / rate) * coats;
  return hours;
}

/**
 * Compute the cost of materials given the gallons required and the unit price
 * (cost to the painter or sale price to the client). This function does not
 * perform rounding of gallons or amounts; call roundCurrency/ceilGallons
 * outside.
 */
export function computeMaterialCost(
  gallons: number,
  unitPrice: number,
): number {
  return gallons * unitPrice;
}

/**
 * Calculate a subtotal from labor, materials, repairs and displacement fees.
 */
export function computeSubtotal(
  labor: number,
  materials: number,
  repairs: number,
  fraisDeplacement: number,
): number {
  return labor + materials + repairs + fraisDeplacement;
}

/**
 * Compute the margin amount based on a margin percentage. The margin is
 * applied to the subtotal. Materials are assumed to already include the sale
 * price (prixVenteCAD) so margin still applies to the entire subtotal for
 * simplicity. If you wish to exclude materials from margin calculations,
 * adjust the inputs accordingly before calling this function.
 */
export function computeMargin(subtotal: number, marginPercent: number): number {
  return (subtotal * marginPercent) / 100;
}

/**
 * Compute taxes for a given amount. In Québec, TPS (5%) and TVQ (9.975%) may
 * apply. The taxesOn flag determines if taxes should be added. Returns the
 * total tax amount.
 */
export function computeTaxes(amount: number, taxesOn: boolean): number {
  if (!taxesOn) return 0;
  const tps = amount * 0.05;
  const tvq = amount * 0.09975;
  return tps + tvq;
}

/**
 * Example high-level function to estimate a simple room using a given
 * productivity rate and paint product. This helper demonstrates how the
 * individual primitives can be combined. A complete implementation would
 * iterate over multiple surfaces, apply different rates and products, and
 * aggregate repairs and extras.
 */
export function estimateRoom(
  room: Room,
  profileRate: number,
  coats: number,
  coverage: number,
  pertePercent: number,
  tauxHoraire: number,
  unitPrice: number,
): {
  areaSqFt: number;
  hours: number;
  gallons: number;
  costMaterials: number;
  costLabor: number;
  costTotal: number;
} {
  // Compute wall area as a baseline. This sample assumes we paint only walls.
  const area = computeWallArea(
    room.L,
    room.W,
    room.H,
    room.nbPortes,
    room.nbFenetres,
  );
  const gallons = computeGallons(area, coats, coverage, pertePercent);
  const hours = computeLaborHours(area, profileRate, coats);
  const costMaterials = computeMaterialCost(gallons, unitPrice);
  const costLabor = hours * tauxHoraire;
  const costTotal = costMaterials + costLabor;
  return {
    areaSqFt: area,
    hours,
    gallons,
    costMaterials,
    costLabor,
    costTotal,
  };
}