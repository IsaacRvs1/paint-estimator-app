import { describe, it, expect } from 'vitest';
import { roundHours, roundCurrency, ceilGallons } from './calcul';

describe('roundHours', () => {
  it('rounds up to nearest quarter hour', () => {
    expect(roundHours(0)).toBe(0);
    expect(roundHours(0.1)).toBe(0.25);
    expect(roundHours(1.12)).toBe(1.25);
    expect(roundHours(2.5)).toBe(2.5);
    expect(roundHours(2.51)).toBe(2.75);
  });
});

describe('roundCurrency', () => {
  it('rounds to nearest cent', () => {
    expect(roundCurrency(0)).toBe(0);
    expect(roundCurrency(1.234)).toBe(1.23);
    expect(roundCurrency(1.235)).toBe(1.24);
  });
});

describe('ceilGallons', () => {
  it('ceil gallons to next whole number with surplus info', () => {
    const result = ceilGallons(3.4);
    expect(result.gallonsFactures).toBe(4);
    expect(result.surplus).toBeCloseTo(0.6);
    const result2 = ceilGallons(4.0);
    expect(result2.gallonsFactures).toBe(4);
    expect(result2.surplus).toBeCloseTo(0);
  });
});