/*
 * Minimal canvas-based UI framework. Widgets are drawn onto an HTMLCanvasElement
 * and receive pointer and keyboard events via a central event dispatcher. The
 * design here is intentionally simple but illustrates the pattern needed to
 * build more complex controls. All coordinates are expressed in device pixels
 * (after scaling for devicePixelRatio) and should be scaled back to logical
 * pixels when handling input.
 */

export interface Widget {
  x: number;
  y: number;
  width: number;
  height: number;
  /** Draw the widget using the provided 2D rendering context. */
  draw(ctx: CanvasRenderingContext2D): void;
  /** Handle pointer events. Returns true if the event was handled. */
  onPointerDown?(x: number, y: number): boolean;
  onPointerUp?(x: number, y: number): boolean;
  onPointerMove?(x: number, y: number): boolean;
  /** Handle keyboard events. Only the focused widget receives keyboard input. */
  onKeyDown?(ev: KeyboardEvent): boolean;
  onKeyPress?(ev: KeyboardEvent): boolean;
  onKeyUp?(ev: KeyboardEvent): boolean;
}

/**
 * Basic rectangular button. Executes a callback when clicked. This button
 * supports keyboard activation via Space/Enter when focused.
 */
export class Button implements Widget {
  x: number;
  y: number;
  width: number;
  height: number;
  label: string;
  onClick: () => void;
  hovered = false;
  focused = false;
  constructor(
    x: number,
    y: number,
    width: number,
    height: number,
    label: string,
    onClick: () => void,
  ) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.label = label;
    this.onClick = onClick;
  }
  draw(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    // Style depends on hover/focus state
    ctx.fillStyle = this.hovered ? '#0077cc' : '#005fa3';
    if (this.focused) {
      ctx.strokeStyle = '#ffbf00';
      ctx.lineWidth = 2;
      ctx.strokeRect(this.x - 2, this.y - 2, this.width + 4, this.height + 4);
    }
    ctx.fillRect(this.x, this.y, this.width, this.height);
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.label, this.x + this.width / 2, this.y + this.height / 2);
    ctx.restore();
  }
  onPointerDown(x: number, y: number): boolean {
    if (this.contains(x, y)) {
      this.hovered = true;
      return true;
    }
    return false;
  }
  onPointerUp(x: number, y: number): boolean {
    if (this.hovered && this.contains(x, y)) {
      this.onClick();
    }
    this.hovered = false;
    return this.contains(x, y);
  }
  onPointerMove(x: number, y: number): boolean {
    this.hovered = this.contains(x, y);
    return false;
  }
  onKeyDown(ev: KeyboardEvent): boolean {
    if (ev.key === ' ' || ev.key === 'Enter') {
      this.onClick();
      return true;
    }
    return false;
  }
  contains(x: number, y: number): boolean {
    return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height;
  }
}

/**
 * Simple text input field. Supports basic editing, selection and caret but
 * intentionally omits many advanced features (compositions, IME, etc.) for
 * brevity. A production implementation should leverage browser APIs where
 * possible to provide a richer experience.
 */
export class TextInput implements Widget {
  x: number;
  y: number;
  width: number;
  height: number;
  value: string = '';
  focused = false;
  private caretPos: number = 0;
  constructor(x: number, y: number, width: number, height: number) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }
  draw(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = this.focused ? '#0077cc' : '#aaaaaa';
    ctx.lineWidth = 1;
    ctx.fillRect(this.x, this.y, this.width, this.height);
    ctx.strokeRect(this.x, this.y, this.width, this.height);
    ctx.fillStyle = '#000000';
    ctx.font = '16px sans-serif';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    const textX = this.x + 4;
    const textY = this.y + this.height / 2;
    ctx.fillText(this.value, textX, textY);
    // Draw caret if focused
    if (this.focused) {
      const metrics = ctx.measureText(this.value.substring(0, this.caretPos));
      const caretX = textX + metrics.width;
      ctx.beginPath();
      ctx.moveTo(caretX, this.y + 4);
      ctx.lineTo(caretX, this.y + this.height - 4);
      ctx.strokeStyle = '#0077cc';
      ctx.stroke();
    }
    ctx.restore();
  }
  onPointerDown(x: number, y: number): boolean {
    if (this.contains(x, y)) {
      this.focused = true;
      // Approximate caret position by measuring text width
      // Note: for simplicity we always set caret at end of text
      this.caretPos = this.value.length;
      return true;
    }
    this.focused = false;
    return false;
  }
  onKeyDown(ev: KeyboardEvent): boolean {
    if (!this.focused) return false;
    if (ev.key === 'Backspace') {
      if (this.caretPos > 0) {
        this.value =
          this.value.substring(0, this.caretPos - 1) + this.value.substring(this.caretPos);
        this.caretPos--;
      }
      return true;
    }
    if (ev.key === 'Delete') {
      if (this.caretPos < this.value.length) {
        this.value =
          this.value.substring(0, this.caretPos) + this.value.substring(this.caretPos + 1);
      }
      return true;
    }
    if (ev.key === 'ArrowLeft') {
      if (this.caretPos > 0) this.caretPos--;
      return true;
    }
    if (ev.key === 'ArrowRight') {
      if (this.caretPos < this.value.length) this.caretPos++;
      return true;
    }
    if (ev.key.length === 1 && !ev.ctrlKey && !ev.metaKey) {
      // Insert character at caret
      this.value =
        this.value.substring(0, this.caretPos) + ev.key + this.value.substring(this.caretPos);
      this.caretPos++;
      return true;
    }
    return false;
  }
  contains(x: number, y: number): boolean {
    return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height;
  }
}

/**
 * UIManager orchestrates drawing and event dispatch to widgets. It scales
 * pointer coordinates according to the canvas device pixel ratio and keeps
 * track of the currently focused widget for keyboard events.
 */
export class UIManager {
  private widgets: Widget[] = [];
  private focusedWidget: Widget | null = null;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private dpr: number;

  constructor(canvas: HTMLCanvasElement, dpr: number) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('2D context not supported');
    this.ctx = ctx;
    this.dpr = dpr;
    this.installEventHandlers();
  }
  addWidget(widget: Widget): void {
    this.widgets.push(widget);
  }
  draw(): void {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    for (const w of this.widgets) {
      w.draw(this.ctx);
    }
  }
  private installEventHandlers(): void {
    this.canvas.addEventListener('pointerdown', (ev) => {
      const { x, y } = this.getEventPos(ev);
      for (const w of this.widgets) {
        if (w.onPointerDown && w.onPointerDown(x, y)) {
          this.focusedWidget = w;
          break;
        }
      }
    });
    this.canvas.addEventListener('pointerup', (ev) => {
      const { x, y } = this.getEventPos(ev);
      for (const w of this.widgets) {
        if (w.onPointerUp) w.onPointerUp(x, y);
      }
    });
    this.canvas.addEventListener('pointermove', (ev) => {
      const { x, y } = this.getEventPos(ev);
      for (const w of this.widgets) {
        if (w.onPointerMove) w.onPointerMove(x, y);
      }
    });
    window.addEventListener('keydown', (ev) => {
      if (this.focusedWidget && this.focusedWidget.onKeyDown) {
        const handled = this.focusedWidget.onKeyDown(ev);
        if (handled) {
          ev.preventDefault();
        }
      }
    });
  }
  /** Convert event coordinates to canvas logical coordinates. */
  private getEventPos(ev: PointerEvent): { x: number; y: number } {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    return {
      x: (ev.clientX - rect.left) * scaleX,
      y: (ev.clientY - rect.top) * scaleY,
    };
  }
}