import { UIManager, Button, TextInput } from '@ui/index';
import {
  computeWallArea,
  computeGallons,
  computeLaborHours,
  computeMaterialCost,
  roundHours,
  ceilGallons,
  roundCurrency,
} from '@domain/calcul';
import { RATE_PROFILES, PRODUCTS } from '@seeds';

/**
 * Entry point for the painting estimator application. This file configures
 * the canvas for high DPI rendering, instantiates the UI manager and hooks up
 * a few simple widgets to demonstrate the calculation engine. A real
 * application would load project data, render multiple screens (accueil,
 * wizard, résumé) and persist user input.
 */

function setupCanvas(): HTMLCanvasElement {
  const canvas = document.getElementById('app') as HTMLCanvasElement;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  // If performance is poor, we could reduce dpr; measure FPS in the render loop.
  function resize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
  }
  window.addEventListener('resize', resize);
  resize();
  return canvas;
}

function main() {
  const canvas = setupCanvas();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const ui = new UIManager(canvas, dpr);
  // Create input fields for length, width and height
  const inputL = new TextInput(20, 40, 120, 32);
  inputL.value = '10';
  const inputW = new TextInput(20, 80, 120, 32);
  inputW.value = '12';
  const inputH = new TextInput(20, 120, 120, 32);
  inputH.value = '8';
  const button = new Button(20, 170, 120, 32, 'Calculer', () => {
    const L = parseFloat(inputL.value) || 0;
    const W = parseFloat(inputW.value) || 0;
    const H = parseFloat(inputH.value) || 0;
    const area = computeWallArea(L, W, H, 1, 1);
    // Use first rate profile and first product as default
    const profile = RATE_PROFILES[0];
    const product = PRODUCTS[1];
    const coats = 2;
    const hours = computeLaborHours(area, profile.taux.murs.global, coats);
    const gallons = computeGallons(area, coats, product.couvertureSqftParGallon, profile.perteMateriauxPercent);
    const charged = ceilGallons(gallons);
    const costMaterials = computeMaterialCost(charged.gallonsFactures, product.prixVenteCAD);
    const costLabor = roundCurrency(roundHours(hours) * 50); // default rate 50 $/h
    const total = roundCurrency(costMaterials + costLabor);
    const message = `Surface murs: ${area.toFixed(1)} pi²\nHeures: ${roundHours(hours)} h\nGallons facturés: ${charged.gallonsFactures} (surplus ${(charged.surplus).toFixed(2)} gal)\nCoût matériaux: ${costMaterials.toFixed(2)} $\nCoût main-d’œuvre: ${costLabor.toFixed(2)} $\nSous-total: ${total.toFixed(2)} $`;
    alert(message);
  });
  ui.addWidget(inputL);
  ui.addWidget(inputW);
  ui.addWidget(inputH);
  ui.addWidget(button);
  function loop() {
    ui.draw();
    requestAnimationFrame(loop);
  }
  loop();
}

document.addEventListener('DOMContentLoaded', main);