import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

/**
 * Generate a simple client estimate PDF. This function demonstrates usage
 * of the pdf-lib library. It produces a single-page PDF containing a title
 * and a table header. A real implementation should lay out the estimate in
 * detail, including client information, room breakdown, pricing and tax.
 */
export async function generateClientEstimatePdf(data: {
  titre: string;
  ligne1: string;
  ligne2: string;
}): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([612, 792]); // Letter size in points
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const { width, height } = page.getSize();
  // Title
  const fontSize = 18;
  const textWidth = font.widthOfTextAtSize(data.titre, fontSize);
  page.drawText(data.titre, {
    x: (width - textWidth) / 2,
    y: height - 60,
    size: fontSize,
    font,
    color: rgb(0.1, 0.1, 0.1),
  });
  // Content lines
  let y = height - 100;
  const bodySize = 12;
  page.drawText(data.ligne1, { x: 50, y, size: bodySize, font });
  y -= 20;
  page.drawText(data.ligne2, { x: 50, y, size: bodySize, font });
  return await pdfDoc.save();
}

/**
 * Generate a simple team sheet PDF. Currently identical to client
 * estimate but can be extended to include task order and checklists.
 */
export async function generateTeamSheetPdf(data: { titre: string }): Promise<Uint8Array> {
  return generateClientEstimatePdf({ titre: data.titre, ligne1: '', ligne2: '' });
}