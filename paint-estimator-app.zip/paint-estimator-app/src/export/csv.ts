/**
 * Convert an array of objects to a CSV string. Column order is derived from
 * the keys of the first object. Values are escaped as needed.
 */
export function toCSV<T extends Record<string, any>>(rows: T[]): string {
  if (rows.length === 0) return '';
  const headers = Object.keys(rows[0]);
  const escape = (v: any) => {
    const s = String(v ?? '');
    if (s.includes(',') || s.includes('"') || s.includes('\n')) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  };
  const lines = [headers.join(',')];
  for (const row of rows) {
    lines.push(headers.map((h) => escape(row[h])).join(','));
  }
  return lines.join('\n');
}

/**
 * Example helper to build a CSV for rooms. This is purely demonstrative.
 */
export function roomsToCSV(rooms: { nom: string; surface: number; gallons: number; hours: number }[]): string {
  return toCSV(rooms);
}

/**
 * Example helper to build a purchase order CSV for paint products. This CSV
 * includes product name, color code, quantity of gallons and optional SKU.
 */
export function purchaseOrderToCSV(items: { nom: string; codeCouleur: string; gallons: number; sku?: string }[]): string {
  return toCSV(items);
}