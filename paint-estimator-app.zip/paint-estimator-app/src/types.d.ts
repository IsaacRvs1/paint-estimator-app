/**
 * Stub module declarations for dependencies that are not available at
 * compile-time in this environment. At runtime, these modules will be
 * resolved from node_modules when installed via npm. Declaring them as
 * 'any' here prevents TypeScript from throwing errors during `tsc --noEmit`.
 */
declare module 'pdf-lib' {
  export type RGB = { r: number; g: number; b: number };
  export const rgb: (r: number, g: number, b: number) => RGB;
  export const StandardFonts: any;
  export class PDFDocument {
    static create(): Promise<PDFDocument>;
    addPage(size?: [number, number]): any;
    embedFont(font: any): Promise<any>;
    save(): Promise<Uint8Array>;
  }
}
declare module 'vitest' {
  export const describe: any;
  export const it: any;
  export const expect: any;
}