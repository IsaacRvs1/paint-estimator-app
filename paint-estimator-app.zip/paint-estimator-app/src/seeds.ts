/**
 * This module defines the initial data that seeds the application. The values
 * here reflect typical productivity rates for residential painting in Québec
 * as described in the specification. All units use either square feet (pi²),
 * linear feet (LF) or units per hour. These values can be edited by the user
 * within the application UI.
 */

export type RateSurfaceRates = {
  global: number;
  coupesMasquage?: number;
  miseEnCouleur?: number;
  texture?: {
    lisse: {
      global: number;
      coupesMasquage?: number;
      miseEnCouleur?: number;
    };
    popcorn: {
      global: number;
      coupesMasquage?: number;
      miseEnCouleur?: number;
    };
  };
};

export interface RateProfile {
  nom: string;
  taux: {
    murs: RateSurfaceRates;
    plafonds: RateSurfaceRates;
    plinthes: { global: number };
    boiseries: { global: number };
    portes: { unitPerHour: number };
    contours: { global: number };
  };
  coefficientsSurface: {
    plafondCathedrale: number;
    cageEscalier: number;
  };
  perteMateriauxPercent: number;
}

export interface Product {
  id: string;
  nom: string;
  description: string;
  type: 'primer' | 'paint' | 'autre';
  couvertureSqftParGallon: number;
  prixCoutCAD: number;
  prixVenteCAD: number;
  imageUrl?: string;
}

export type RepairPresetType =
  | 'standardMultiplicateur'
  | 'majeureUnitaire'
  | 'calfeutrageLF'
  | 'rebouchageUnitaire'
  | 'blocageTachesUnitaire';

export interface RepairPreset {
  id: string;
  label: string;
  type: RepairPresetType;
  valeur: {
    multiplicateur?: number;
    prixUnitaireCAD?: number;
  };
}

/**
 * Initial productivity profiles. These values come from the specification and
 * reflect typical rates for different application methods. See the README
 * for details. The productivity rates are expressed per hour.
 */
export const RATE_PROFILES: RateProfile[] = [
  {
    nom: 'Rouleau – Standard résidentiel',
    taux: {
      murs: { global: 200, coupesMasquage: 120, miseEnCouleur: 260 },
      plafonds: {
        global: 180,
        coupesMasquage: 110,
        miseEnCouleur: 240,
        texture: {
          lisse: { global: 180, coupesMasquage: 110, miseEnCouleur: 240 },
          popcorn: { global: 120, coupesMasquage: 80, miseEnCouleur: 160 },
        },
      },
      plinthes: { global: 60 },
      boiseries: { global: 40 },
      portes: { unitPerHour: 2.5 },
      contours: { global: 45 },
    },
    coefficientsSurface: {
      plafondCathedrale: 1.35,
      cageEscalier: 1.25,
    },
    perteMateriauxPercent: 8,
  },
  {
    nom: 'Pulvérisation – Murs/Plafonds',
    taux: {
      murs: { global: 300, coupesMasquage: 100, miseEnCouleur: 380 },
      plafonds: {
        global: 280,
        coupesMasquage: 90,
        miseEnCouleur: 360,
        texture: {
          lisse: { global: 280, coupesMasquage: 90, miseEnCouleur: 360 },
          popcorn: { global: 180, coupesMasquage: 70, miseEnCouleur: 240 },
        },
      },
      plinthes: { global: 70 },
      boiseries: { global: 45 },
      portes: { unitPerHour: 3.0 },
      contours: { global: 50 },
    },
    coefficientsSurface: {
      plafondCathedrale: 1.35,
      cageEscalier: 1.3,
    },
    perteMateriauxPercent: 15,
  },
  {
    nom: 'Haute finition – Cuisines/Vanités',
    taux: {
      murs: { global: 160, coupesMasquage: 100, miseEnCouleur: 210 },
      plafonds: {
        global: 150,
        coupesMasquage: 95,
        miseEnCouleur: 200,
        texture: {
          lisse: { global: 150, coupesMasquage: 95, miseEnCouleur: 200 },
          popcorn: { global: 110, coupesMasquage: 70, miseEnCouleur: 150 },
        },
      },
      plinthes: { global: 50 },
      boiseries: { global: 35 },
      portes: { unitPerHour: 2.0 },
      contours: { global: 40 },
    },
    coefficientsSurface: {
      plafondCathedrale: 1.4,
      cageEscalier: 1.3,
    },
    perteMateriauxPercent: 12,
  },
  {
    nom: 'Plafond Popcorn dédié',
    taux: {
      murs: { global: 200 },
      plafonds: {
        global: 120,
        coupesMasquage: 80,
        miseEnCouleur: 160,
        texture: {
          lisse: { global: 120, coupesMasquage: 80, miseEnCouleur: 160 },
          popcorn: { global: 120, coupesMasquage: 80, miseEnCouleur: 160 },
        },
      },
      plinthes: { global: 60 },
      boiseries: { global: 40 },
      portes: { unitPerHour: 2.5 },
      contours: { global: 45 },
    },
    coefficientsSurface: {
      plafondCathedrale: 1.35,
      cageEscalier: 1.25,
    },
    perteMateriauxPercent: 10,
  },
  {
    nom: 'Stairwell/Cathédrale',
    taux: {
      murs: { global: 200 },
      plafonds: {
        global: 180,
        coupesMasquage: 110,
        miseEnCouleur: 240,
        texture: {
          lisse: { global: 180, coupesMasquage: 110, miseEnCouleur: 240 },
          popcorn: { global: 120, coupesMasquage: 80, miseEnCouleur: 160 },
        },
      },
      plinthes: { global: 60 },
      boiseries: { global: 40 },
      portes: { unitPerHour: 2.5 },
      contours: { global: 45 },
    },
    coefficientsSurface: {
      plafondCathedrale: 1.35,
      cageEscalier: 1.25,
    },
    perteMateriauxPercent: 8,
  },
  {
    nom: 'Chantier occupé / Meubles présents',
    taux: {
      murs: { global: 200 },
      plafonds: {
        global: 180,
        coupesMasquage: 110,
        miseEnCouleur: 240,
        texture: {
          lisse: { global: 180, coupesMasquage: 110, miseEnCouleur: 240 },
          popcorn: { global: 120, coupesMasquage: 80, miseEnCouleur: 160 },
        },
      },
      plinthes: { global: 60 },
      boiseries: { global: 40 },
      portes: { unitPerHour: 2.5 },
      contours: { global: 45 },
    },
    coefficientsSurface: {
      plafondCathedrale: 1.35,
      cageEscalier: 1.25,
    },
    perteMateriauxPercent: 8,
  },
];

/**
 * Product seeds. Two basic paint products are provided as examples. Users can
 * define additional products inside the application. Prices are in CAD.
 */
export const PRODUCTS: Product[] = [
  {
    id: 'P1',
    nom: 'Primer intérieur universel',
    description: 'Apprêt intérieur polyvalent',
    type: 'primer',
    couvertureSqftParGallon: 300,
    prixCoutCAD: 34.0,
    prixVenteCAD: 49.0,
    imageUrl: '',
  },
  {
    id: 'P2',
    nom: 'Peinture latex intérieur eggshell',
    description: 'Peinture latex finition eggshell pour intérieur',
    type: 'paint',
    couvertureSqftParGallon: 350,
    prixCoutCAD: 38.0,
    prixVenteCAD: 59.0,
    imageUrl: '',
  },
];

/**
 * Repair presets seeds. Values come from the specification. These presets
 * represent common repair operations with either a multiplicative factor on
 * hours or a price per unit/linear foot.
 */
export const REPAIR_PRESETS: RepairPreset[] = [
  {
    id: 'R1',
    label: 'Gyproc mineur',
    type: 'standardMultiplicateur',
    valeur: { multiplicateur: 1.05 },
  },
  {
    id: 'R2',
    label: 'Gyproc modéré',
    type: 'standardMultiplicateur',
    valeur: { multiplicateur: 1.12 },
  },
  {
    id: 'R3',
    label: 'Gyproc majeur',
    type: 'standardMultiplicateur',
    valeur: { multiplicateur: 1.25 },
  },
  {
    id: 'R4',
    label: 'Calfeutrage boiseries',
    type: 'calfeutrageLF',
    valeur: { prixUnitaireCAD: 0.6 },
  },
  {
    id: 'R5',
    label: 'Rebouchage boiseries',
    type: 'rebouchageUnitaire',
    valeur: { prixUnitaireCAD: 4.0 },
  },
  {
    id: 'R6',
    label: 'Blocage de taches (spot primer)',
    type: 'blocageTachesUnitaire',
    valeur: { prixUnitaireCAD: 6.0 },
  },
];